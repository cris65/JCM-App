# JULIET-CLOUD-MAGAZINE-HTML-APP
my HTML app for JULIET 

After using some software to build APP i come out with this idea to make an HTML responsive APP
so i do a Website and make an app using PHONEGAP, i tested on IOS and Android and the APP works good, now i want to publish,
but i have to fix some point that looks to much for me, since i'm not a developer.....

When i install the IPA on the device the APP works correctly Now i have an issue with the NSPhotoLibraryUsageDescription !!!
This APP attempts to access privacy-sensitive data without a usage description. The APP info.plist must contain an NSPhotoLibraryUsageDescription key with a string value explaining to user how the APP uses this data........

Hope someone can help me on solving thi issue

Thanks Cris

